# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pydumpling']

package_data = \
{'': ['*']}

install_requires = \
['dill>=0.3.2,<0.4.0', 'six>=1.16.0,<2.0.0']

setup_kwargs = {
    'name': 'pydumpling',
    'version': '0.1.1',
    'description': '',
    'long_description': '# Python post-mortem debugging\n\nEnglish | [简体中文](README_zh.md)\n\nIt\'s a fork/optimized version from [elifiner/pydump](https://github.com/elifiner/pydump).The main optimization points are：\n* Optimize code structure && remove redundant code\n* fix bug in python2.7 && support python3.10+\n* supported more pdb commnd\n\n\nPydump writes the traceback of an exception into a file and \ncan later load it in a Python debugger. It works with the built-in \npdb and with other popular debuggers (pudb, ipdb and pdbpp).\n\n## Why use pydumpling?\n\n* We usually use `try... except ... ` to catch exceptions that occur in our programs, but do we really know why they occur?\n* When your project is running online, you suddenly get an unexpected exception that causes the process to exit. How do you reproduce this problem?\n* Not enough information in the logs to help us pinpoint online issues?\n* If we were able to save the exception error and then use the debugger to recover the traceback at that time, we could see the entire stack variables along the traceback as if you had caught the exception at the local breakpoint.\n\n## Install pydumpling\nPython version：>= 2.7, >=3.6\n\nNot published in pypi，so use the `.whl` file install pydumpling in the dist path.\n```\npip install dist/pydumpling-0.1.0-py2.py3-none-any.whl\n```\n\n## How to use pydumpling\n\nIn the code, find the place where we need to do the `try ... except ...` and use `save_dumpling()`. When we save the dump file, it will default to `${exception filename}:${error lineno}.dump`.\n\n```python\nfrom pydumpling import save_dumping\n\ndef inner():\n    a = 1\n    b = "2"\n    c = a + b\n\n\ndef outer():\n    inner()\n\n\nif __name__ == "__main__":\n    try:\n        outer()\n    except Exception:\n        save_dumping("test.dump")\n\n```\n\nNow we have the `test.dump` file, which we can use `debub_dumpling` to do pdb debug:\n```python     \nPython 3.10.6 (main, Aug  1 2022, 20:38:21) [GCC 5.4.0 20160609] on linux\nType "help", "copyright", "credits" or "license" for more information.\n>>> from pydumpling import debug_dumpling\n>>> debug_dumpling("test.dump")\n> /home/loyd/vscodeFiles/pydumpling/test.py(6)inner()\n-> c = a + b\n(Pdb) list 1,17\n  1     from pydumpling import save_dumping\n  2  \n  3     def inner():\n  4  >>     a = 1\n  5         b = "2"\n  6  ->     c = a + b\n  7  \n  8  \n  9     def outer():\n 10         inner()\n 11  \n 12  \n 13     if __name__ == "__main__":\n 14         try:\n 15             outer()\n 16         except Exception:\n 17             save_dumping("test.dump")\n(Pdb) ll\n  3     def inner():\n  4  >>     a = 1\n  5         b = "2"\n  6  ->     c = a + b\n(Pdb) bt\n  /home/loyd/vscodeFiles/pydumpling/test.py(15)<module>()\n-> outer()\n  /home/loyd/vscodeFiles/pydumpling/test.py(10)outer()\n-> inner()\n> /home/loyd/vscodeFiles/pydumpling/test.py(6)inner()\n-> c = a + b\n(Pdb) pp a\n1\n(Pdb) pp b\n\'2\'\n(Pdb) u\n> /home/loyd/vscodeFiles/pydumpling/test.py(10)outer()\n-> inner()\n(Pdb) ll\n  9     def outer():\n 10  ->     inner()\n(Pdb) \n```\n## TODO\n- []\n',
    'author': 'cocolato',
    'author_email': 'haiizhu@outlook.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*',
}


setup(**setup_kwargs)
