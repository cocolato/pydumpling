# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pydumpling']

package_data = \
{'': ['*']}

install_requires = \
['dill>=0.3.2,<0.4.0', 'six>=1.16.0,<2.0.0']

setup_kwargs = {
    'name': 'pydumpling',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Python post-mortem debugging\n\nIt's a fork/optimized version from [elifiner/pydump](https://github.com/elifiner/pydump).\n\nPydump writes the traceback of an exception into a file and \ncan later load it in a Python debugger. It works with the built-in \npdb and with other popular debuggers (pudb, ipdb and pdbpp).\n\n## Why use pydumpling?\n\nI spent way too much time trying to discern details about bugs from\nlogs that don't have enough information in them. Wouldn't it be nice\nto be able to open a debugger and load the entire stack of the crashed\nprocess into it and look around like you would if it crashed on your own \nmachine?\n\n## Install pydumpling\n\nThis project (or approach) might be useful in multiprocessing environments\nrunning many unattended processes. The most common case for me is on\nproduction web servers that I can't really stop and debug. For each \nexception caught, I write a dump file and I can debug each issue on \nmy own time, on my own box, even if I don't have the source, since \nthe relevant source is stored in the dump file.\n\n## How to use pydumpling\n\n## TODO\n- []\n",
    'author': 'cocolato',
    'author_email': 'haiizhu@outlook.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*',
}


setup(**setup_kwargs)
